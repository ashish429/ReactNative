import { createStore, compose, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import { persistStore, persistCombineReducers } from "redux-persist";
import storage from "redux-persist/es/storage";


const config = {
  key: "root",
  storage
};

const perReducers = persistCombineReducers(config);
const store = createStore(perReducers, {}, compose(applyMiddleware(thunk)));
export let persistor = persistStore(store);

export default store;
